# Professional Grade Calculator

A modern, responsive grade calculator built with **React + Vite + Tailwind**.  
Supports percentage/letter/points scales, partial credit, session history, quick chart legend, and JSON export.

## 🚀 Local Development

```bash
npm install
npm run dev
```

## 🏗️ Build

```bash
npm run build
npm run preview
```

## 🌐 Deploy on Netlify

1. Push this folder to a GitHub repo.
2. In Netlify, **New site from Git** → select your repo.
3. Build command: `npm run build`
4. Publish directory: `dist`
5. Add the provided `netlify.toml` (already included).

## 🔧 Custom Grading Scales

You can store custom scales in `localStorage` under the key `customGradingScales` as an array:

```json
[
  {
    "name": "My Letter Scale",
    "type": "letter",
    "is_default": true,
    "scale": [
      { "min": 85, "max": 100, "grade": "A", "color": "#16a34a" },
      { "min": 75, "max": 84.99, "grade": "B", "color": "#84cc16" },
      { "min": 65, "max": 74.99, "grade": "C", "color": "#f59e0b" },
      { "min": 50, "max": 64.99, "grade": "D", "color": "#f97316" },
      { "min": 0, "max": 49.99, "grade": "F", "color": "#dc2626" }
    ]
  }
]
```

## 📁 Project Structure

```
grade-calculator/
├─ index.html
├─ netlify.toml
├─ package.json
├─ postcss.config.js
├─ tailwind.config.js
├─ vite.config.js
├─ jsconfig.json
├─ src/
│  ├─ index.css
│  ├─ main.jsx
│  ├─ App.jsx
│  ├─ entities/
│  │  └─ GradeScale.js
│  └─ components/
│     └─ calculator/
│        ├─ GradeCalculator.jsx
│        ├─ SettingsPanel.jsx
│        ├─ QuickChart.jsx
│        ├─ ExportButton.jsx
│        └─ SessionHistory.jsx
└─ README.md
```

Enjoy! 🎉
