import React from 'react'

export default function QuickChart({ totalQuestions, showDecimals, gradingScale }) {
  // Simple legend from gradingScale
  const items = (gradingScale?.scale || []).map((s, i) => ({
    label: s.grade === 'percentage' ? 'Percentage' : s.grade,
    color: s.color || '#0ea5e9'
  }))

  return (
    <div className="p-5 rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white/60 dark:bg-neutral-900/60 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="font-semibold">Quick Chart</div>
        <div className="text-sm text-muted-foreground">Total Questions: {totalQuestions}</div>
      </div>

      <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-2">
        {items.map((it, idx) => (
          <div key={idx} className="flex items-center gap-2 text-sm">
            <div className="w-3 h-3 rounded-sm" style={{ background: it.color }}></div>
            <div>{it.label}</div>
          </div>
        ))}
      </div>

      <div className="mt-4 text-sm text-muted-foreground">
        This chart shows the active grading format and legend colors.
      </div>
    </div>
  )
}
