import React, { useEffect, useMemo, useState } from 'react'

export default function GradeCalculator({
  showDecimals,
  gradingScale,
  onGradeChange,
  onResetCalculation,
}) {
  const [totalQuestions, setTotalQuestions] = useState(100)
  const [wrongAnswers, setWrongAnswers] = useState(0)
  const [partialCount, setPartialCount] = useState(0)
  const [partialCredit, setPartialCredit] = useState(0.5) // 0..1

  const computed = useMemo(() => {
    const t = Math.max(0, Number(totalQuestions) || 0)
    const w = Math.min(t, Math.max(0, Number(wrongAnswers) || 0))
    const pCount = Math.min(t - w, Math.max(0, Number(partialCount) || 0))
    const pCredit = Math.min(1, Math.max(0, Number(partialCredit) || 0))

    const fullCorrect = t - w - pCount
    const score = (fullCorrect + pCount * pCredit) / t * 100 || 0
    const percentage = Math.max(0, Math.min(100, score))
    const letter = getLetterFromScale(percentage, gradingScale)

    return {
      totalQuestions: t,
      wrongAnswers: w,
      partialCount: pCount,
      partialCredit: pCredit,
      percentage,
      letter,
    }
  }, [totalQuestions, wrongAnswers, partialCount, partialCredit, gradingScale])

  useEffect(() => {
    onGradeChange?.(computed)
  }, [computed, onGradeChange])

  function reset() {
    onResetCalculation?.(computed)
    setWrongAnswers(0)
    setPartialCount(0)
    setPartialCredit(0.5)
  }

  const percentDisplay = showDecimals ? computed.percentage.toFixed(2) : Math.round(computed.percentage)

  return (
    <div className="p-6 rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white/60 dark:bg-neutral-900/60 shadow-sm space-y-5">
      <div className="grid sm:grid-cols-2 gap-4">
        <NumberField label="Total Questions" value={totalQuestions} onChange={setTotalQuestions} min={1} />
        <NumberField label="Wrong Answers" value={wrongAnswers} onChange={setWrongAnswers} min={0} max={totalQuestions} />
        <NumberField label="Partially Correct (count)" value={partialCount} onChange={setPartialCount} min={0} max={Math.max(0, totalQuestions - wrongAnswers)} />
        <NumberField label="Partial Credit per Question (0-1)" step="0.05" value={partialCredit} onChange={setPartialCredit} min={0} max={1} />
      </div>

      <div className="flex items-center justify-between p-4 rounded-xl bg-neutral-100 dark:bg-neutral-800">
        <div className="space-y-1">
          <div className="text-sm text-muted-foreground">Score</div>
          <div className="text-3xl font-bold">{percentDisplay}%</div>
          {gradingScale?.type === 'letter' && <div className="text-lg font-semibold">{computed.letter}</div>}
        </div>
        <div className="flex-1 mx-6">
          <Progress value={computed.percentage} />
        </div>
        <button
          className="px-4 py-2 rounded-xl bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 hover:opacity-90"
          onClick={reset}
        >
          Reset
        </button>
      </div>
    </div>
  )
}

function NumberField({ label, value, onChange, min, max, step='1' }) {
  return (
    <label className="block">
      <span className="text-sm text-muted-foreground">{label}</span>
      <input
        type="number"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-xl border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 px-3 py-2 outline-none focus:ring-2 focus:ring-sky-500"
      />
    </label>
  )
}

function Progress({ value }) {
  return (
    <div className="w-full h-4 bg-neutral-200 dark:bg-neutral-700 rounded-full overflow-hidden">
      <div className="h-full rounded-full bg-gradient-to-r from-teal-500 to-cyan-500" style={{ width: `${Math.min(100, Math.max(0, value))}%`}} />
    </div>
  )
}

function getLetterFromScale(percentage, scale) {
  if (!scale) return ''
  if (scale.type === 'letter') {
    const found = (scale.scale || []).find(s => percentage >= s.min && percentage <= s.max)
    return found?.grade || ''
  }
  return ''
}
