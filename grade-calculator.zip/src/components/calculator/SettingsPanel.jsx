import React from 'react'

export default function SettingsPanel({
  showDecimals,
  onShowDecimalsChange,
  showChart,
  onShowChartChange,
  gradingScale,
  onGradingScaleChange,
  gradingScales = [],
}) {
  return (
    <div className="p-5 rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white/60 dark:bg-neutral-900/60 shadow-sm space-y-5">
      <h3 className="text-lg font-semibold">Settings</h3>

      <Toggle id="decimals" label="Show decimal places" checked={showDecimals} onChange={onShowDecimalsChange} />
      <Toggle id="chart" label="Show quick chart" checked={showChart} onChange={onShowChartChange} />

      <div className="space-y-2">
        <div className="text-sm text-muted-foreground">Grading Scale</div>
        <select
          className="w-full rounded-xl border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 px-3 py-2"
          value={gradingScale?.name}
          onChange={(e) => {
            const found = gradingScales.find(s => s.name === e.target.value)
            onGradingScaleChange?.(found || gradingScale)
          }}
        >
          {gradingScales.map(s => (
            <option key={s.name} value={s.name}>{s.name}</option>
          ))}
        </select>
      </div>
    </div>
  )
}

function Toggle({ id, label, checked, onChange }) {
  return (
    <label htmlFor={id} className="flex items-center justify-between gap-4">
      <span className="text-sm">{label}</span>
      <input
        id={id}
        type="checkbox"
        className="w-5 h-5 accent-cyan-600"
        checked={!!checked}
        onChange={(e) => onChange?.(e.target.checked)}
      />
    </label>
  )
}
