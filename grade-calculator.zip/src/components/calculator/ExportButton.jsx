import React from 'react'

export default function ExportButton({ gradeData, showDecimals }) {
  function exportJson() {
    const data = {
      ...gradeData,
      exportedAt: new Date().toISOString(),
      showDecimals: !!showDecimals,
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'grade-result.json'
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <button
      onClick={exportJson}
      className="w-full px-4 py-2 rounded-xl bg-gradient-to-r from-teal-600 to-cyan-600 text-white hover:opacity-90"
    >
      Export Result (JSON)
    </button>
  )
}
