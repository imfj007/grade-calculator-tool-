import React from 'react'

export default function SessionHistory({ history = [], onClear }) {
  return (
    <div className="p-5 rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white/60 dark:bg-neutral-900/60 shadow-sm space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Session History</h3>
        {history.length > 0 && (
          <button onClick={onClear} className="text-sm underline">Clear</button>
        )}
      </div>

      {history.length === 0 ? (
        <div className="text-sm text-muted-foreground">No calculations yet. Run some and they will appear here.</div>
      ) : (
        <ul className="space-y-2">
          {history.map((h, i) => (
            <li key={i} className="text-sm flex items-center justify-between rounded-lg p-2 bg-neutral-100 dark:bg-neutral-800">
              <span>{new Date().toLocaleTimeString()}</span>
              <span>{Math.round(h.percentage)}%</span>
              <span>{h.totalQuestions} Qs</span>
              <span>Wrong: {h.wrongAnswers}</span>
              <span>Partial: {h.partialCount} × {h.partialCredit}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
